#!/usr/bin/python

import boto3

class VgwCreation:

    def __init__(self, requestId, accountName, vpcId):
        print("Defining the Variables")
        self.accountName = accountName
        self.requestId = requestId
        self.vpcId = vpcId

    def createVgw(self):
        print('Entering createVgw method')
        #Creating the resources needed to create the VGW
        ec2 = boto3.resource('ec2')
         
        #Creating the necessary code to create the Virtual Gateway
        vgw_options = boto3.client('ec2')
        response = vgw_options.create_vpn_gateway(
                 AvailabilityZone = 'us-east-1a',
                 Type = 'ipsec.1',
                 AmazonSideAsn = 65421
             )

        print('\nNow trying to extract the vgw id from the response')
        vgw_status = ''
        while 'available' not in vgw_status: 
            for vgw_results in response.values():
                if 'VpnGatewayId' in vgw_results:
                    vgw_id = vgw_results['VpnGatewayId']
                if 'State' in vgw_results:
                    vgw_status = vgw_results['State']

        print('\nNow attaching the vgw to VPC %s' % (self.vpcId))
        vgw_options.attach_vpn_gateway(VpcId = self.vpcId, VpnGatewayId = vgw_id)
        ec2.create_tags(Resources=[vgw_id], Tags=[{"Key": "Name", "Value" : self.accountName}])
        ec2.create_tags(Resources=[vgw_id], Tags=[{"Key": "Request Id", "Value": self.requestId}])

        #Creating the subnet necessary to support Transit Gateway
        print('\nNow creating the subnets necessary to support Transit Gateway')
        subnet_option = boto3.client('ec2')
        subnet_values = ['192.170.0.0/28:a','192.170.0.16/28:b','192.170.0.32/28:c']
        for subnet_cidr in subnet_values:
            cidr = subnet_cidr.split(":")[0]
            az = subnet_cidr.split(":")[1]
            response = subnet_option.create_subnet(
                        AvailabilityZone = 'us-east-1'+az,
                        CidrBlock = cidr,
                        VpcId = self.vpcId)
            for subnet_results in response.values():
                if 'SubnetId' in subnet_results:
                    subnetId = subnet_results['SubnetId']
                    ec2.create_tags(Resources=[subnetId], Tags=[{'Key': 'Name', 'Value' : 'TGW_Subnet_AZ_'+az.upper() }])
                    ec2.create_tags(Resources=[subnetId], Tags=[{'Key': 'Request Id', 'Value': self.requestId}])


requestId = 'REQ0001'
accountName = 'Jim'
vpc_Id = 'vpc-05384b97c7cec5dd1'
#vpc_Id = 'vpc-096fbc5d68b9b4686'
#tgw_Id = 'tgw-0011ac3311e03bf3a'
response = VgwCreation(requestId,accountName,vpc_Id)
VgwCreation.createVgw(response)
