#!/usr/bin/python

import boto3
from datetime import datetime

class VpcAttachTransitGateway:

    def __init__(self, vpcId, tgwId):
        self.vpcId = vpcId
        self.tgwId = tgwId
        
    def attachTransitGateway(self):
        print("\nEntering Transit Gateway method")
        tgw_client = boto3.client('ec2')

        print("\nObtain the default subnet for vpc %s" % (self.vpcId))
        #response = tgw_client.describe_subnets(Filters=[ {'Name':'vpc-id', 'Values':[self.vpcId]},
		#	        {'Name':'cidr-block', 'Values':['192.170.0.0/28','192.170.0.16/28','192.170.0.32/28']} ] 
	    #    )
        
        # subnet_values = []
        # for response_results in response.values():
        #     for subnet_results in response_results:
        #         if 'SubnetId' in subnet_results:
        #             subnet_values.append(subnet_results['SubnetId'])
                    
        # print("\nAttempting to create transit gateway attachment to %s for vpc %s" % (self.vpcId, self.tgwId))
        # response = tgw_client.create_transit_gateway_vpc_attachment(
        #         TransitGatewayId=self.tgwId,
        #         VpcId=self.vpcId,
        #         SubnetIds=[subnet_values[0], subnet_values[1], subnet_values[2]])
                
        # for response_results in response.values():
        #     if 'TransitGatewayAttachmentId' in response_results:
        #         attachmentId = response_results['TransitGatewayAttachmentId']

        # print("\nNow checking the status of the the gateway attachment %s" % (attachmentId))                
        # attachmentStatus = ''
        # while 'available' not in attachmentStatus:
        #     response = tgw_client.describe_transit_gateway_vpc_attachments(TransitGatewayAttachmentIds=[attachmentId])
        #     for response_results in response.values():
        #         for attach_results in response_results:
        #             if 'State' in attach_results:
        #                 attachmentStatus = attach_results['State']
        
        # print("The status of the attached gateway is %s" % (attachmentStatus))

        response = tgw_client.describe_route_tables(
            Filters=[ {'Name':'vpc-id', 'Values':[self.vpcId]} 
                      #{'Name':'association.main','Values':['true']} ]
                      ])
        #print(response) 
        for rt_response_values in response.values():
            for rt_values in rt_response_values:
                if 'RouteTableId' in rt_values:
                    print(rt_values['RouteTableId'])
                    rteTblId = rt_values['RouteTableId']

        tgw_client.create_route(DestinationCidrBlock = '0.0.0.0/0', 
                                TransitGatewayId = self.tgwId,
                                RouteTableId = rteTblId)
        
vpc_Id = 'vpc-096fbc5d68b9b4686'
tgw_Id = 'tgw-05212da30655e9b2a'

response = VpcAttachTransitGateway(vpc_Id, tgw_Id)
VpcAttachTransitGateway.attachTransitGateway(response)


