#!/usr/bin/python

import boto3

class IgwCreation:

    def __init__(self, requestId, accountName,vpcId):
        """
        This method will initialize self
        """
        print('Defining the variables needed to create account with IGW')
        self.accountName = accountName
        self.requestId = requestId
        self.vpcId = vpcId

    def createIgw(self):
        """
        Function will be used to create and attach IGW to VPC
           accountName = The name of the account owner
           requestId = The request id that is use to request the creation
           vpcId = The VPC id need to attach the internet gateway (IGW) to the VPC
           return = Need to determine if we are returning something
        """
        #Creating the resources needed to create the IGW
        print('Entering createIgw method')
        ec2 = boto3.resource('ec2')
        igw = ec2.create_internet_gateway()
        
        #Creating the clien need to attach the IGW to the VPC
        igw_client = boto3.client('ec2')
        response = igw_client.attach_internet_gateway(
                        InternetGatewayId = igw.id, 
                        VpcId = self.vpcId
                    )
        
        ec2.create_tags(Resources=[igw.id], Tags=[{"Key": "Name", "Value" : self.accountName}])
        ec2.create_tags(Resources=[igw.id], Tags=[{"Key": "Request Id", "Value": self.requestId}])
        